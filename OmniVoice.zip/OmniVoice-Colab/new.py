import pysrt
from pydub import AudioSegment
from pydub.silence import detect_nonsilent
from gradio_client import Client, handle_file
import os
import re
import math
import time # Thêm thư viện time để đo thời gian

# ==========================================
# CONFIG
# ==========================================
SRT_FILE_PATH = "./source/srt/test.srt"
OUTPUT_FILE_PATH = "new_output.wav"
REF_AUDIO_PATH = "./audio_Cut.MP3"

REF_TEXT = (
    "Bệ hạ, thần có nghìn kế có thể giải quyết được "
    "nỗi lo trước mắt này. Không được sỉ nhục di hài "
    "tướng sĩ quân ta. Bệ hạ, vậy thần có trăm kế."
)

# ==========================================
# TIMING CONFIG
# ==========================================
SAFE_VOICE_GAP = 30
TIMING_TOLERANCE_MS = 300
MAX_AI_SPEED = 1.20
MIN_AI_SPEED = 1.0
MAX_OVERFLOW_MS = 400
WORDS_PER_SECOND = 3.4
TRIM_SILENCE_THRESHOLD = -45
TRIM_BUFFER_MS = 120

MAX_OVERLAP_MS = 50 
ANCHOR_GAP_MS = 800

# Bắt đầu bấm giờ toàn bộ chương trình
total_start_time = time.time()

# ==========================================
# CONNECT
# ==========================================
print("🔌 Đang kết nối OmniVoice...")
t0 = time.time()
try:
    client = Client("http://localhost:8001")
    print(f"✅ Kết nối thành công (mất {time.time() - t0:.2f}s)")
except Exception as e:
    print(f"❌ Lỗi kết nối: {e}")
    exit()

# ==========================================
# CACHE REF AUDIO
# ==========================================
print("🎤 Đang chuẩn bị giọng mẫu...")
t0 = time.time()
CACHED_REF_AUDIO = handle_file(REF_AUDIO_PATH)
print(f"✅ Chuẩn bị xong (mất {time.time() - t0:.2f}s)")

# ==========================================
# VIETNAMESE FILTER
# ==========================================
vietnamese_chars_pattern = re.compile(
    r'[a-zA-Z0-9àáạảãâầấậẩẫăằắặẳẵèéẹẻẽ'
    r'êềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡ'
    r'ùúụủũưừứựửữỳýỵỷỹđĐ]'
)

# ==========================================
# TTS GENERATOR
# ==========================================
def generate_cloned_audio(text_to_read, custom_sp, estimated_duration_sec):
    result = client.predict(
        text=text_to_read,
        lang="Vietnamese",
        ref_aud=CACHED_REF_AUDIO,
        ref_text=REF_TEXT,
        instruct="",
        ns=32,
        gs=2.0,
        dn=True,
        sp=custom_sp,
        du=estimated_duration_sec,
        pp=True,
        po=True,
        api_name="/_clone_fn"
    )
    return result[0]

# ==========================================
# TRIM SILENCE
# ==========================================
def trim_silence(audio_segment, silence_thresh=TRIM_SILENCE_THRESHOLD, buffer=TRIM_BUFFER_MS):
    nonsilent_ranges = detect_nonsilent(
        audio_segment,
        min_silence_len=120,
        silence_thresh=silence_thresh
    )
    if nonsilent_ranges:
        start_trim = max(0, nonsilent_ranges[0][0] - buffer)
        end_trim = min(len(audio_segment), nonsilent_ranges[-1][1] + buffer)
        return audio_segment[start_trim:end_trim]
    return audio_segment

# ==========================================
# ESTIMATE DURATION
# ==========================================
def estimate_duration_ms(text):
    words = text.split()
    word_count = len(words)
    estimated_sec = word_count / WORDS_PER_SECOND
    estimated_ms = estimated_sec * 1000
    return max(1200, int(estimated_ms))

# ==========================================
# CALCULATE AI SPEED
# ==========================================
def calculate_dynamic_speed(estimated_need_ms, allowed_duration_ms):
    target_duration = allowed_duration_ms - TIMING_TOLERANCE_MS
    if estimated_need_ms <= target_duration:
        return 1.0
    speed = estimated_need_ms / target_duration
    return round(min(1.45, max(MIN_AI_SPEED, speed)), 2)

# ==========================================
# MAIN
# ==========================================
def main():
    print(f"\n📂 Đang đọc SRT: {SRT_FILE_PATH}")
    subs = pysrt.open(SRT_FILE_PATH, encoding="utf-8")
    if not subs:
        print("❌ File SRT trống")
        return

    original_end_time_ms = subs[-1].end.ordinal
    final_audio = AudioSegment.silent(duration=original_end_time_ms + 5000)
    total_lines = len(subs)

    print(f"\n🎬 Bắt đầu clone {total_lines} câu thoại")
    print("=" * 60)

    max_actual_end_time_ms = 0
    current_head_ms = 0

    for i, sub in enumerate(subs):
        text = sub.text.replace('\n', ' ').strip()
        start_time_ms = sub.start.ordinal
        end_time_ms = sub.end.ordinal
        allowed_duration_ms = end_time_ms - start_time_ms

        readable_chars = vietnamese_chars_pattern.findall(text)
        if not readable_chars:
            print(f"[{i+1}/{total_lines}] ⏩ Skip non-readable")
            continue

        try:
            estimated_need_ms = estimate_duration_ms(text)
            calculated_sp = calculate_dynamic_speed(estimated_need_ms, allowed_duration_ms)
            estimated_duration_sec = max(2.5, estimated_need_ms / 1000)

            print(f"[{i+1}/{total_lines}] 🎤 Clone: {text[:40]}...")
            print(f"   ⏱ Allowed: {allowed_duration_ms}ms | 🧠 Est: {estimated_need_ms}ms | ⚙️ Speed: {calculated_sp}x")

            # --- ĐO THỜI GIAN AI GENERATE ---
            gen_start_time = time.time()
            temp_wav_path = generate_cloned_audio(text, calculated_sp, estimated_duration_sec)
            gen_time = time.time() - gen_start_time
            print(f"   ✅ Generate xong (mất {gen_time:.2f}s)")
            # --------------------------------

            sentence_audio = AudioSegment.from_wav(temp_wav_path)
            sentence_audio = trim_silence(sentence_audio)
            
            actual_duration_ms = len(sentence_audio)
            original_gap = start_time_ms - current_head_ms

            if original_gap > ANCHOR_GAP_MS:
                safe_start_ms = start_time_ms
                print(f"   ⚓ Reset mốc, dọn dẹp độ trễ.")
            else:
                safe_start_ms = max(start_time_ms, current_head_ms - MAX_OVERLAP_MS)
                
            if safe_start_ms > start_time_ms:
                shift_amount = safe_start_ms - start_time_ms
                print(f"   🔄 Bị đẩy lùi: +{shift_amount}ms")

            final_audio = final_audio.overlay(sentence_audio, position=safe_start_ms)
            current_head_ms = safe_start_ms + actual_duration_ms
            max_actual_end_time_ms = max(max_actual_end_time_ms, current_head_ms)

            if os.path.exists(temp_wav_path):
                os.remove(temp_wav_path)

        except Exception as e:
            print(f"❌ Lỗi dòng {i+1}: {e}")

    print("\n" + "=" * 60)
    print("📊 TIMELINE REPORT")
    print(f"📄 SRT End: {original_end_time_ms / 1000:.2f}s")
    print(f"🎵 Audio End: {max_actual_end_time_ms / 1000:.2f}s")
    drift = max_actual_end_time_ms - original_end_time_ms
    print(f"📉 Drift: {drift}ms")
    print("=" * 60)

    export_duration = max(original_end_time_ms, max_actual_end_time_ms)
    final_audio = final_audio[:export_duration]

    print("\n💾 Đang export WAV...")
    t0 = time.time()
    final_audio.export(OUTPUT_FILE_PATH, format="wav", parameters=["-ar", "24000"])
    
    total_time = time.time() - total_start_time
    print(f"✅ Hoàn tất Export (mất {time.time() - t0:.2f}s)")
    print(f"🚀 TỔNG THỜI GIAN CHẠY TOÀN BỘ SCRIPT: {total_time:.2f}s ({total_time/60:.2f} phút)")

if __name__ == "__main__":
    main()