@echo off
REM OmniVoice Demo Launcher
REM This script starts the OmniVoice Gradio web interface

call python src/clone.py 

echo.
echo closed.
pause
