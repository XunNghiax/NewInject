import re

# Đọc file phụ đề của bạn
with open('./source/srt/test_ready.srt', 'r', encoding='utf-8') as file:
    lines = file.readlines()

new_lines = []
counter = 1

for line in lines:
    # Nếu dòng chỉ chứa số (số thứ tự của phụ đề)
    if re.match(r'^\d+$', line.strip()):
        new_lines.append(f"{counter}\n")
        counter += 1
    else:
        new_lines.append(line)

# Xuất ra file mới hoàn chỉnh
with open('test_ready_final.srt', 'w', encoding='utf-8') as file:
    file.writelines(new_lines)
    
print("Đã cập nhật xong số thứ tự!")