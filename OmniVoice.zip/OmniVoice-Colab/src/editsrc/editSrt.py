import pysrt

# ==========================================
# CẤU HÌNH
# ==========================================

INPUT_SRT = "./source/srt/TestVideoVI.srt"
OUTPUT_SRT = "./source/srt/test_ready.srt"

VIDEO_SPEED = 0.8

# ---- Timing Config ----
SAFE_GAP_MS = 50           # khoảng cách an toàn giữa 2 subtitle
MIN_DURATION_MS = 500      # subtitle tối thiểu
MAX_EXTENSION_MS = 1500    # kéo dài tối đa khi fill gap
MIN_GAP_TO_FILL = 100      # chỉ fill khi gap > giá trị này

# ==========================================
# HÀM LOAD FILE AN TOÀN
# ==========================================

def load_srt(filepath):
    encodings = [
        "utf-8",
        "utf-8-sig",
        "cp936",
        "gbk"
    ]

    for enc in encodings:
        try:
            print(f"🔍 Thử đọc file với encoding: {enc}")
            return pysrt.open(filepath, encoding=enc)
        except:
            pass

    raise Exception("❌ Không thể đọc file SRT với các encoding phổ biến.")

# ==========================================
# HÀM CHÍNH
# ==========================================

def process_srt():

    # --------------------------------------
    # VALIDATE
    # --------------------------------------

    if VIDEO_SPEED <= 0:
        raise ValueError("❌ VIDEO_SPEED phải lớn hơn 0")

    print("=" * 60)
    print(f"📂 Đang xử lý file: {INPUT_SRT}")

    # --------------------------------------
    # LOAD FILE
    # --------------------------------------

    try:
        subs = load_srt(INPUT_SRT)
    except Exception as e:
        print(str(e))
        return

    original_count = len(subs)

    # --------------------------------------
    # BƯỚC 1: SCALE THEO TỐC ĐỘ VIDEO
    # --------------------------------------

    time_multiplier = 1 / VIDEO_SPEED

    print(f"⚙️ Video Speed: {VIDEO_SPEED}x")
    print(f"⏱️ Time Multiplier: {time_multiplier:.2f}x")

    for sub in subs:

        sub.start.ordinal = int(sub.start.ordinal * time_multiplier)
        sub.end.ordinal = int(sub.end.ordinal * time_multiplier)

    # --------------------------------------
    # BƯỚC 2: XÓA SUBTITLE RÁC
    # --------------------------------------

    cleaned_subs = pysrt.SubRipFile()

    removed_empty = 0

    for sub in subs:

        if sub.text.strip():
            cleaned_subs.append(sub)
        else:
            removed_empty += 1

    print(f"🧹 Đã xóa {removed_empty} subtitle rỗng")

    # --------------------------------------
    # BƯỚC 3: FIX DURATION QUÁ NGẮN
    # --------------------------------------

    for sub in cleaned_subs:

        duration = sub.end.ordinal - sub.start.ordinal

        if duration < MIN_DURATION_MS:
            sub.end.ordinal = sub.start.ordinal + MIN_DURATION_MS

    # --------------------------------------
    # BƯỚC 4: FIX OVERLAP + FILL GAP
    # --------------------------------------

    for i in range(len(cleaned_subs) - 1):

        current_sub = cleaned_subs[i]
        next_sub = cleaned_subs[i + 1]

        current_end = current_sub.end.ordinal
        next_start = next_sub.start.ordinal

        gap_ms = next_start - current_end

        # ----------------------------------
        # CASE 1: OVERLAP
        # ----------------------------------

        if current_end >= next_start:

            new_end = max(
                current_sub.start.ordinal + MIN_DURATION_MS,
                next_start - SAFE_GAP_MS
            )

            current_sub.end.ordinal = new_end

        # ----------------------------------
        # CASE 2: GAP QUÁ LỚN
        # ----------------------------------

        elif gap_ms > MIN_GAP_TO_FILL:

            extend_ms = min(
                gap_ms - SAFE_GAP_MS,
                MAX_EXTENSION_MS
            )

            current_sub.end.ordinal += extend_ms

    # --------------------------------------
    # BƯỚC 5: RE-INDEX
    # --------------------------------------

    for idx, sub in enumerate(cleaned_subs, start=1):
        sub.index = idx

    # --------------------------------------
    # BƯỚC 6: SAVE FILE
    # --------------------------------------

    try:

        cleaned_subs.save(
            OUTPUT_SRT,
            encoding="utf-8"
        )

        print("=" * 60)
        print("✅ HOÀN TẤT")
        print(f"📄 Tổng subtitle gốc: {original_count}")
        print(f"📄 Subtitle sau xử lý: {len(cleaned_subs)}")
        print(f"💾 File output: {OUTPUT_SRT}")
        print("=" * 60)

    except Exception as e:

        print(f"❌ Lỗi khi lưu file: {e}")

if __name__ == "__main__":
    process_srt()