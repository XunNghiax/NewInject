@echo off
REM OmniVoice Demo Launcher
REM This script starts the OmniVoice Gradio web interface

echo.
echo ========================================
echo   OmniVoice - Text-to-Speech Demo
echo ========================================
echo.
echo Starting the web interface...
echo Please wait while the model loads...
echo.

call .venv\Scripts\activate.bat
omnivoice-demo --ip 0.0.0.0 --port 8001

echo.
echo Demo closed.
pause
